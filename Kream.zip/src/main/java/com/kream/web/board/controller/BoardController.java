package com.kream.web.board.controller;

import javax.inject.Inject;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.kream.web.board.model.BoardVO;
import com.kream.web.board.model.ReplyVO;
import com.kream.web.board.service.BoardService;
import com.kream.web.common.Search;

@Controller
@RequestMapping(value = "/board")
public class BoardController {



	@Inject
	private BoardService boardService;


	@RequestMapping(value = "/getBoardList", method = RequestMethod.GET) //getBoardList
	public String getBoardList(Model model
			, @RequestParam(required = false, defaultValue = "1") int page
			, @RequestParam(required = false, defaultValue = "1") int range
			, @RequestParam(required = false, defaultValue = "title") String searchType
			, @RequestParam(required = false) String keyword
			, @ModelAttribute("search") Search search

) throws Exception {
		search.setSearchType(searchType);
		search.setKeyword(keyword);

		model.addAttribute("search", search);
		//��ü �Խñ� ����
		int listCnt = boardService.getBoardListCnt(search);
		//�˻�
		search.pageInfo(page, range, listCnt);
		//����¡
   		model.addAttribute("pagination", search);
		model.addAttribute("boardList", boardService.getBoardList(search));
		return "board/index";

	}
	
	@RequestMapping("/boardForm")
	public String boardForm(@ModelAttribute("boardVO") BoardVO vo, Model model) {
	return "board/boardForm";
	}
	
	@RequestMapping(value = "/saveBoard", method = RequestMethod.POST)
	public String saveBoard(@ModelAttribute("BoardVO") BoardVO boardVO
			, @RequestParam("mode") String mode
) throws Exception {
		if (mode.equals("edit")) {
			boardService.updateBoard(boardVO);
		} else {
			boardService.insertBoard(boardVO);
		}


		return "redirect:/board/getBoardList";

	}

	@RequestMapping(value = "/getBoardContent", method = RequestMethod.GET)
	public String getBoardContent(Model model, HttpServletRequest request,
			HttpServletResponse response, @RequestParam("bid") int bid) throws Exception {
		
		boolean coocheck = false;
		Cookie oldCookie = null;
		
	    Cookie[] cookies = request.getCookies();
	    if (cookies != null) {
	        for (Cookie cookie : cookies) {
	            if (cookie.getName().equals("boardView")) {
	                oldCookie = cookie;
	            }
	        }
	    }

	    if (oldCookie != null) {
	        if (!oldCookie.getValue().contains("[" + bid + "]")) {
	        	coocheck = true;
	            oldCookie.setValue(oldCookie.getValue() + "_[" + bid + "]");
	            oldCookie.setPath("/");
	            oldCookie.setMaxAge(30); // 30��
	            response.addCookie(oldCookie);
	        }
	    } else {
	    	coocheck = true;
	        Cookie newCookie = new Cookie("boardView","[" + bid + "]");
	        newCookie.setPath("/");
	        newCookie.setMaxAge(30);
	        response.addCookie(newCookie);
	    }
		model.addAttribute("boardContent", boardService.getBoardContent(bid,coocheck));
		model.addAttribute("replyVO", new ReplyVO());
		return "board/boardContent";
	}
	@RequestMapping(value = "/editForm", method = RequestMethod.GET)

	public String editForm(@RequestParam("bid") int bid

, @RequestParam("mode") String mode, Model model) throws Exception {
		boolean coocheck = false;
		model.addAttribute("boardContent", boardService.getBoardContent(bid,coocheck));
		model.addAttribute("mode", mode);
		model.addAttribute("boardVO", new BoardVO());
		return "board/boardForm";
	}

	
	@RequestMapping(value = "/deleteBoard", method = RequestMethod.GET)
	public String deleteBoard(RedirectAttributes rttr, @RequestParam("bid") int bid) throws Exception {
		boardService.deleteBoard(bid);
		return "redirect:/board/getBoardList";
	}







}	


